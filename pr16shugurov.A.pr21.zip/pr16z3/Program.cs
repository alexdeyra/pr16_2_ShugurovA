﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;
using System.Globalization;

namespace pr16z3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Чтение данных из файла
            string[] lines;
            try
            {
                lines = File.ReadAllLines("input.txt");
            }
            catch (IOException)
            {
                Console.WriteLine("Ошибка при чтении файла. Проверьте наличие файла и доступность его для чтения.");
                return;
            }

            List<double> numbers = new List<double>();
            foreach (string line in lines)
            {
                string[] parts = line.Split(';');
                foreach (string part in parts)
                {
                    if (double.TryParse(part, out double number))
                    {
                        numbers.Add(number);
                    }
                    else
                    {
                        Console.WriteLine($"Ошибка при обработке числа: '{part}' не является допустимым числом.");
                    }
                }
            }

            // Вывод чисел и их частоты
            Console.WriteLine("Число\tЧастота");
            Console.WriteLine("----------------");
            var frequencyDict = numbers.GroupBy(x => x).ToDictionary(g => g.Key, g => g.Count());
            foreach (var pair in frequencyDict)
            {
                Console.WriteLine($"{pair.Key}\t{pair.Value}");
            }

            // Создание нового массива
            List<double> newArray = new List<double>();
            foreach (var number in numbers)
            {
                newArray.Add(number * frequencyDict[number]);
            }

            // Вывод нового массива
            Console.WriteLine("\nЧисло\tЧастота (старого массива)");
            Console.WriteLine("-----------------------------");
            foreach (var pair in frequencyDict)
            {
                Console.WriteLine($"{pair.Key * pair.Value}\t{pair.Value}");
            }
            Console.ReadKey();
        }
    }
}
