﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pr16z4
{
    public partial class Form1 : Form
    {
        private List<(string Country, long Population)> countries = new List<(string, long)>();
        public Form1()
        {
            InitializeComponent();
        }
        private List<Country> LoadCountriesFromFile(string filePath)
        {
            List<Country> countries = new List<Country>();
            string[] lines = File.ReadAllLines(filePath);

            foreach (string line in lines)
            {
                string[] parts = line.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                if (parts.Length >= 2)
                {
                    string name = string.Join(" ", parts, 0, parts.Length - 1);
                    long population = Convert.ToInt64(parts[parts.Length - 1]);
                    countries.Add(new Country(name, population));
                }
            }

            return countries;
        }

        private int CompareCountries(Country c1, Country c2)
        {
            int result = c1.Name.Length.CompareTo(c2.Name.Length);
            if (result == 0)
            {
                result = string.Compare(c1.Name, c2.Name, StringComparison.Ordinal);
            }
            return result;
        }

        private void btnLoadCountries_Click_1(object sender, EventArgs e)
        {
            long minPopulation = Convert.ToInt64(txtMinPopulation.Text);
            List<Country> countries = LoadCountriesFromFile("countries.txt");
            countries = countries.FindAll(c => c.Population > minPopulation);
            countries.Sort(CompareCountries);

            lstCountries.Items.Clear();
            foreach (Country country in countries)
            {
                lstCountries.Items.Add(country.ToString());
            }
        }
    }

    class Country
    {
        public string Name { get; set; }
        public long Population { get; set; }

        public Country(string name, long population)
        {
            Name = name;
            Population = population;
        }

        public override string ToString()
        {
            return $"{Name} {Population}";
        }
    }
}