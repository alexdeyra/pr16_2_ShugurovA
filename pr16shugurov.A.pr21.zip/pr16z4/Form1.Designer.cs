﻿namespace pr16z4
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnLoadCountries = new System.Windows.Forms.Button();
            this.txtMinPopulation = new System.Windows.Forms.TextBox();
            this.lstCountries = new System.Windows.Forms.ListView();
            this.SuspendLayout();
            // 
            // btnLoadCountries
            // 
            this.btnLoadCountries.Location = new System.Drawing.Point(22, 45);
            this.btnLoadCountries.Name = "btnLoadCountries";
            this.btnLoadCountries.Size = new System.Drawing.Size(75, 23);
            this.btnLoadCountries.TabIndex = 0;
            this.btnLoadCountries.Text = "button1";
            this.btnLoadCountries.UseVisualStyleBackColor = true;
            this.btnLoadCountries.Click += new System.EventHandler(this.btnLoadCountries_Click_1);
            // 
            // txtMinPopulation
            // 
            this.txtMinPopulation.Location = new System.Drawing.Point(22, 12);
            this.txtMinPopulation.Name = "txtMinPopulation";
            this.txtMinPopulation.Size = new System.Drawing.Size(100, 22);
            this.txtMinPopulation.TabIndex = 1;
            // 
            // lstCountries
            // 
            this.lstCountries.HideSelection = false;
            this.lstCountries.Location = new System.Drawing.Point(203, 3);
            this.lstCountries.Name = "lstCountries";
            this.lstCountries.Size = new System.Drawing.Size(1052, 329);
            this.lstCountries.TabIndex = 2;
            this.lstCountries.UseCompatibleStateImageBehavior = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1361, 593);
            this.Controls.Add(this.lstCountries);
            this.Controls.Add(this.txtMinPopulation);
            this.Controls.Add(this.btnLoadCountries);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnLoadCountries;
        private System.Windows.Forms.TextBox txtMinPopulation;
        private System.Windows.Forms.ListView lstCountries;
    }
}

